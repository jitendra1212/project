# SpringBoot-SpringData-CURD-Operations-WebApp


This application created using Spring Boot, Spring Data modules to perform CURD operations in web application with Oracle Database

#Database details configured in application.properties file
